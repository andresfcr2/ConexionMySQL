package andres.interfazgrafica;

import java.util.ArrayList;

public class Registros {

    ArrayList<Usuario> usuarios;

    public Registros() {
        this.usuarios = new ArrayList<>();
    }

    public void agregarUsuario(Usuario user) {
        this.usuarios.add(user);
    }

    public String editarUsuario(String nombre, double nota) {
        for (Usuario u : this.usuarios) {
            if (u.nombre.equals(nombre)) {
                u.nota = nota;
                return "Usuario actualizado con exito";
            }
        }
        return "Usuario no encontrado";
    }

    public String eliminarUsuario(String nombre) {
        boolean eliminado = this.usuarios.removeIf(u -> u.nombre.equals(nombre));
        if (eliminado) {
            return "Usuario eliminado con exito";
        }
        return "Usuario no encontrado";

    }

    public ArrayList<Usuario> obtenerUsuarios() {
        return this.usuarios;
    }
}
